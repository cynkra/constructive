# new_relational()

    Code
      new_relational(list())
    Output
      list()
      attr(,"class")
      [1] "relational"

