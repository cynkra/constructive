# collect() works

    Code
      print(z)
    Output
        a
      1 1

