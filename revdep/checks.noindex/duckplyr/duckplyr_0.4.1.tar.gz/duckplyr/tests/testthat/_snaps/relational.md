# rel_try() with reason

    Code
      rel_try(`Not affected` = FALSE, Affected = TRUE, { })
    Message
      Requested fallback for relational:
      i Affected
    Output
      NULL

