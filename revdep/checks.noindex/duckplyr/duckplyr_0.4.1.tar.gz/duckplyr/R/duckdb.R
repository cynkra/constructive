duckdb <- asNamespace("duckdb")
