# Overwritten in meta.R
meta_ext_register <- function(...) {}
meta_rel_register <- function(...) {}
meta_rel_register_df <- function(...) {}
meta_rel_register_file <- function(...) {}
meta_rel_get <- function(...) {}
meta_macro_register <- function(...) {}
