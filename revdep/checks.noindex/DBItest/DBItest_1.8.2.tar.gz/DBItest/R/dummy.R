dummy <- function() {
  # Satisfy R CMD check
  desc::desc_get_deps()
}
