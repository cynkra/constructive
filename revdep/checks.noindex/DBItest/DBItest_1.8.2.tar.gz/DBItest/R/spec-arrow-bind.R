# FIXME: Adapt tests from spec_meta_bind
spec_arrow_bind <- list()
