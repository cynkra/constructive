# FIXME: Adapt tests from spec_result_roundtrip
spec_arrow_roundtrip <- list()
