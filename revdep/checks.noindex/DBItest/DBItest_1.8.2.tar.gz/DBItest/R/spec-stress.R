#' @format NULL
spec_stress <- c(
  spec_stress_connection
)
