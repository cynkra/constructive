test_that("default context is NULL", {
  expect_null(get_default_context())
})
